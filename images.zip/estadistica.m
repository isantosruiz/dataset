function [m,s] = estadistica(x)
N = numel(x);
m = sum(x)/N;
s = sqrt(sum((x-m).^2)/(N-1));