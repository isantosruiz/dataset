function [a,p,c] = poligono(x,y)
% cerrar el polígono
X = [x,x(1)];
Y = [y,y(1)];
% calcular el área
der = X(1:end-1).*Y(2:end);
izq = Y(1:end-1).*X(2:end);
a = abs(sum(der)-sum(izq))/2;
% calcular el perímetro
dx = X(1:end-1)-X(2:end);
dy = Y(1:end-1)-Y(2:end);
p = sum(sqrt(dx.^2+dy.^2));
% calcular el centroide
c = [mean(x),mean(y)];